Left Stick: Move and Operate Inventory
Right Stick: Camera
Right Bumper: Attack
Left Bumper: Parry
Left Trigger: Dodge
A: Interact with Doors and Pick Up Objects
B: Use Object
X: Throw Object
Back Button: Open/Close Inventory (the inventory bugs out if you go outside of bounds so be careful)

Everything in this project excluding the inventory system was made by me.